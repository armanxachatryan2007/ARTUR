// ////////////////////////////////////////////////  Example 2
const http = require('http');
const PORT = 3000;

const server = http.createServer();

const friends = [
    {
        id: 0,
        name: 'Narek'
    },

    {
        id: 1,
        name: 'Gago'
    },

    {
        id: 2,
        name: 'Rafo'
    }
];

server.on('request', (req, res) => {
    // console.log(req.url);
    const items = req.url.split('/');

    console.log('items =>', items);

    if(req.method === 'GET' && items[1] === 'friends') {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        if(items.length === 3) {
            res.end(JSON.stringify(friends[items[2]]));
        }else {
            res.end(JSON.stringify(friends));
        }
    }else if(req.method === 'POST') {
        req.on('data', (result) => {
            const friend = result.toString();
            console.log('friend with json format string =>', typeof friend, friend);
            console.log('friend with object =>', typeof JSON.parse(friend), JSON.parse(friend));
            friends.push(JSON.parse(friend));
            console.log(friends);
        })
    }else if(items[1] === 'messages') {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/html');
        res.write('<html>');
        res.write('<body>');
        res.write('<div>');
        res.write('Hello Saqo');
        res.write('</div>');
        res.write('</body>');
        res.write('</html>');
        res.end();
    } else {
        res.statusCode = 404;
        res.end();
    }
})

server.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`);
})

// ////////////////////////////////////////// BROWSER-i CONSOLE-um gri es u kashxati
// fetch('http://localhost:3000/friends', {
//     method: 'POST',
//     body: JSON.stringify({id: 3, name: 'Aram'})
// });