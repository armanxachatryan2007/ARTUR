// ////////////////////////////////////////////////  Example 1
// const http = require('http');
// const PORT = 3000;

// const server = http.createServer((request, response) => {
//     response.writeHead(200, {
//         'Content-Type': 'text/plain',
//     });

//     response.end('Send response data');
    
// });


// server.listen(PORT, () => {
//     console.log(`Listening on port ${PORT} ...`);
// }); // 127.0.0.1 => localhost
