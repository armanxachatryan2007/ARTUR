// ////////////////////////////////////////////////  Exercise
const http = require('http');
const PORT = 3000;

const server = http.createServer();

const friends = [
    {
        id: 0,
        name: 'Narek'
    },

    {
        id: 1,
        name: 'Gago'
    },

    {
        id: 2,
        name: 'Rafo'
    }
];

server.on('request', (req, res) => {
    // console.log(req.url);
    const items = req.url.split('/');

    console.log('items =>', items);

    if(req.method === 'GET' && items[1] === 'friends') {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        if(items.length === 3) {
            res.end(JSON.stringify(friends[items[2]]));
        }else {
            res.end(JSON.stringify(friends));
        }
    }else if(req.method === 'POST') {
        req.on('data', (result) => {
            const friend = result.toString();
            friends.push(JSON.parse(friend));
            console.log(friends);
        })
    }else if(req.method === 'PUT' && friends.length >= 4) {
        req.on('data', (result) => {
            const friendName = result.toString();
            friends[3].name = JSON.parse(friendName);
            console.log(friends);
        })
    }else if(req.method === 'DELETE' && friends.length >= 4) {
            friends.pop();
            console.log(friends);
    }else if(items[1] === 'messages') {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/html');
        res.write('<html>');
        res.write('<body>');
        res.write('<div>');
        res.write('Hello Saqo');
        res.write('</div>');
        res.write('</body>');
        res.write('</html>');
        res.end();
    } else {
        res.statusCode = 404;
        res.end();
    }
})

server.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`);
})

// ////////////////////////////////////////// BROWSER-i CONSOLE-um gri sranq u kashxati
// fetch('http://localhost:3000/friends', {
//     method: 'POST',
//     body: JSON.stringify({id: 3, name: 'Aram'})
// });

// fetch('http://localhost:3000/friends/3', {
//     method: "PUT",
//     body: JSON.stringify('Karen')
// });

// fetch('http://localhost:3000/friends/3', {
//     method: "DELETE",
//     body: JSON.stringify({id: 3, name: 'Karen'})
// })