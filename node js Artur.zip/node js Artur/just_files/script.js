// Exercise 1

// const input = [ 1, -4, 12, 0, -3, 29, -150];
// let result = input.filter(i => i > 0)
//   .reduce((x, y) => x + y, 0);
// console.log(result);

// Exercise 2

// const input = 'George Raymond Richard Martin';
// let result = input.split(' ').map(i => i[0]).join('');
// console.log(result);

// Exercise 3

// const input = [
//     {
//       name: 'John',
//       age: 13
//     },
//     {
//       name: 'Mark',
//       age: 56,
//     },
//     {
//       name: 'Rachel',
//       age: 45,
//     },
//     {
//       name: 'Nate',
//       age: 67,
//     },
//     {
//       name: 'Jeniffer',
//       age: 65,
//     }
//   ];

// const ageArray = input.map(input =>input.age);
// let result = [Math.min(... ageArray), Math.max(... ageArray), Math.max(... ageArray) - Math.min(... ageArray)];
// console.log(result);

// Exercise 4

// const input = [
//     ['a', 'b', 'c'],
//     ['c', 'd', 'f'],
//     ['d', 'f', 'g'],
//   ];
// let result = {
//     a: 0,
//     b: 0,
//     c: 0,
//     d: 0,
//     f: 0,
//     g: 0
//   }
// let array = input.flat();
// for(let i = 0; i < array.length; i++) {
//     result[array[i]]++;
// }
// console.log(result);


// Exercise 13.07.2022

// function checkObject(obj1, obj2) {
//     if(typeof obj1 == typeof obj1) {
//         if(typeof obj1 == "object" && obj1 != null) {
//             let equal = true;
//             for(let key in obj1) {
//               if (obj1.hasOwnProperty(key) && obj2.hasOwnProperty(key)) {
//                 if (!checkObject(obj1[key], obj2[key])) {
//                   equal = false;
//                 }
//               } else {
//                 equal = false;
//               }
//             }
//             return equal;
//         } else {
//             return obj1 === obj2;
//         }
//     } else {
//         return false;
//     }
// }
// let object = {
//     a:1,
//     b:2
// };
// let object1 = {
//     a:1,
//     b:2
// };
// console.log(checkObject({a:1, b:2}, {a:1, b:3}));
// console.log(checkObject(object, {a:1, b:2}));
// console.log(checkObject(object1,object));
// console.log(checkObject(object1, {a:1,b:3}));
// console.log(checkObject({a:1, b:2},{a:1,b:2}));







