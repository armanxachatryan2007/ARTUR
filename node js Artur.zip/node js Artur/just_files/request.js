function encrypt(data){
    return 'encrypted data';
}

function send(url){
    const encrData = encrypt(data);
    console.log(`sending ${encrData} to ${url}`);
} 



module.exports ={ 
    send
}