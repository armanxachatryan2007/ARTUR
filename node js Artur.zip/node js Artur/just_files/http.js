const { send } = require('./request')

function requesthttp(url, data){
    send(url, data );
    return read();
}
