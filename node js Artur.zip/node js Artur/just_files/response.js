function decrypt(){
    return `decrypted data:`
};

function read(){
    return decrypt();
};