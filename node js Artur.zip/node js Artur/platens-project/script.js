const { parse } = require('csv-parse');
const fs = require('fs');

const result = [];

fs.createReadStream('nasa.csv')
.pipe(parse({
    comment: '#',
    columns: true
}))
.on('data', (data) => {
    result.push(data);
})
.on('error', (err) => {
    console.log(err);
})
.on('end', () => {
    let res = result.filter(function(elem){
    if(elem['koi_disposition'] == 'CONFIRMED')
    return elem;
})
    console.log('data =>', res);
})