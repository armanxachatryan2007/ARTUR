const axios = require('axios');


axios.get('https://www.google.com')
   .then((response) => {
        console.log('data => ', response);
    })
    
    .catch((error) => {
        console.log(error);
    }) 

