const print = new Promise((resolve, reject) => {
    const  x = 5;

        if(x > 3){
            resolve('yes');
        }else{
            reject('No!!');
        }
 });

 print
 .then((result) => {
    console.log('then =>',result);
 })
 .catch((error) => {
    console.log(error);
 });








