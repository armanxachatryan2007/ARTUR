// /////////////////////////////////// Example 1
let a, b, rest;
[a, b] = [10, 20];

console.log(a);
// expected output: 10

console.log(b);
// expected output: 20

[a, b, ...rest] = [10, 20, 30, 40, 50];

console.log(rest);
// expected output: Array [30,40,50]


// /////////////////////////////////////// Example 2
let x = 1243;
let y = 5674;
[x,y] = [y,x];
console.log(x);
console.log(y);


// ///////////////////////////////////////// Example 3
const obj = { c: 1, d: 2 };
const { c, d } = obj;
// is equivalent to:
// const a = obj.a;
// const b = obj.b;
console.log(c,d);