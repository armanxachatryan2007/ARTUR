// NPM Modules
const express = require('express');

// Local Modules
const friendsRouter = require('./routes/friends.router');
const messagesRouter = require('./routes/messages.router');

const app = express();

const PORT = 3000;

app.use((req, res, next) => {
    const start = Date.now();
    next();
    const delta = Date.now() - start;

    console.log(`The time is ${delta} ms`);
});

app.use(express.json());

// Friends
app.use('/friends', friendsRouter);

// Messages
app.use('/messages', messagesRouter);

app.listen(PORT, () => {
    console.log(`Server is connected on port ${PORT}...`);
});


// tested with POSTMAN