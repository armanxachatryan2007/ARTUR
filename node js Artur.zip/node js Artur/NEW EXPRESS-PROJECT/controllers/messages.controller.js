function getMessage(req, res) {
    res.send('Hello World');
}

function postMessage(req, res) {
    console.log('Message is posted');
}

module.exports = {
    getMessage,
    postMessage
}