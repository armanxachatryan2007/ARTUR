// Local Modules
const model = require('../models/friends.model');

function getFriends(req, res) {
    res.json(model);
}

function getFriend(req, res) {
    const id = Number(req.params.friendId);
    const friend = model[id];

    if(friend) {
        res.status(200);
        res.json(friend);
    }else{
        res.status(404);
        res.json({
            error: 'Friend Not Found'
        });
    }
}

function postFriend(req, res) {
    const newFriend = {
        id: model.length,
        name: req.body.name
    }

    model.push(newFriend);

    console.log('body =>', req.body);
    console.log(model);

    res.json(newFriend);
}

function putFriendName(req, res) {
    const lastFriendName = req.body.name;
    model[model.length - 1].name = lastFriendName;
    
    console.log(model);

    res.json(lastFriendName);
}

function deleteFriend(req, res) {
    model.pop();
    res.json(model);

    console.log(model);
}

module.exports = {
    getFriends,
    getFriend,
    postFriend,
    putFriendName,
    deleteFriend
}