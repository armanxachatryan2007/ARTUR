const friends = [
    {
        id: 0,
        name: 'Armen'
    },

    {
        id: 1,
        name: 'Karen'
    },

    {
        id: 2,
        name: 'Arsen'
    }
];

module.exports = friends;