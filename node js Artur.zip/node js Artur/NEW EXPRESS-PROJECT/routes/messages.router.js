// NPM Modules
const express = require('express');

// Local Modules
const messagesController = require('../controllers/messages.controller');


const messagesRouter = express.Router();

// Messages
messagesRouter.get('/', messagesController.getMessage);
messagesRouter.post('/', messagesController.postMessage);

module.exports = messagesRouter;