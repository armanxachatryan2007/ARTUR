// Promise.all() == (iterable»)(orinak Array, vori mej bolor value-nery unen index) metod, vory veradarznum e Array-i mej bolor drakan ardyunq unecox Promise-nery(resolve), isk ete gone meky uni bacasakan ardyunq(reject), miangamic veradarcnum e bacasakany(reject)
// First example
const promise1 = Promise.resolve(3);
const promise2 = 42;
const promise3 = new Promise((resolve, reject) => {
  setTimeout(resolve, 100, 'foo');
});

Promise.all([promise1, promise2, promise3]).then((values) => {
  console.log(values);
});
// expected output: Array [3, 42, "foo"]


// Second example
var p1 = new Promise((resolve, reject) => {
    setTimeout(resolve, 1000, "one");
  });
  var p2 = new Promise((resolve, reject) => {
    setTimeout(resolve, 2000, "two");
  });
  var p3 = new Promise((resolve, reject) => {
    setTimeout(resolve, 3000, "three");
  });
  var p4 = new Promise((resolve, reject) => {
    setTimeout(resolve, 4000, "four");
  });
  var p5 = new Promise((resolve, reject) => {
  // Promise.all
    reject("reject");
  });
  
  Promise.all([p1, p2, p3, p4, p5]).then(value => {
    console.log(value);
  }, reason => {
    console.log(reason)
  });
  //"reject"
