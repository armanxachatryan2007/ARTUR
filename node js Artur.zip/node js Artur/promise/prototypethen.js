// then() մեթոդը վերադարձնում է Promise: Այն պահանջում է երկու արգումենտ՝ Promise-ի հաջողության(resolve) և ձախողման(reject) դեպքերի համար:
// // Syntax
// p.then(onFulfilled, [onRejected]);

// p.then(value => {
//   // выполнение
//   }, reason => {
//   // отклонение
// });

// Example
const p1 = new Promise((resolve, reject) => {
    resolve('Success!');
    // or
    // reject(new Error("Error!"));
  });
  
  p1.then(value => {
    console.log(value); // Success!
  }, reason => {
    console.error(reason); // Error!
  });