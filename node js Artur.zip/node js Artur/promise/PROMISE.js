// Promise == «Խոստում», առարկան իրենից ներկայացնում է ասինխրոն գործողության վերջնական ավարտը (կամ ձախողումը) եւ դրա արդյունքում ստացված արժեքը:
// Example 1
const pr = new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('foo');
    }, 300);
  });
  
  pr.then((value) => {
    console.log(value);
    // expected output: "foo"
  });
  
  console.log(pr);
  // expected output: [object Promise]


// Example 2
function promise1() {
    const pr = new Promise((resolve, reject) => {
        setTimeout(() => resolve(3), 3000);
  })
  return pr;
}

function promise2() {
    const pr = new Promise((resolve, reject) => {
        setTimeout(() => resolve(5), 2000);
  })
  return pr;
}

promise1().then((data) => {
    console.log(data);
})

promise2().then((data) => {
    console.log(data);
})
