// Promise.race() == xostum method, vory veradardznum e arajiny ardyunq tvac arjeqy(kap chuni drakan arjeq e te bacasakan)
// Example 1
const promise1 = new Promise((resolve, reject) => {
    setTimeout(resolve, 2000, 'one');
  });
  
  const promise2 = new Promise((resolve, reject) => {
    setTimeout(resolve, 1000, 'two');
  });

  Promise.race([promise1, promise2]).then((value) => {
    console.log(value);
    // Both resolve, but promise2 is faster
  });
  // expected output: "two"



// Example 2
const p1 = new Promise(function(resolve, reject) {
  setTimeout(() => resolve('one'), 500);
});
const p2 = new Promise(function(resolve, reject) {
  setTimeout(() => resolve('two'), 100);
});

Promise.race([p1, p2])
.then(function(value) {
console.log(value); // "two"
// Both fulfill, but p2 is faster
});

const p3 = new Promise(function(resolve, reject) {
  setTimeout(() => resolve('three'), 100);
});
const p4 = new Promise(function(resolve, reject) {
  setTimeout(() => reject(new Error('four')), 500);
});

Promise.race([p3, p4])
.then(function(value) {
console.log(value); // "three"
// p3 is faster, so it fulfills
}, function(error) {
// Not called
});

const p5 = new Promise(function(resolve, reject) {
  setTimeout(() => resolve('five'), 500);
});
const p6 = new Promise(function(resolve, reject) {
  setTimeout(() => reject(new Error('six')), 100);
});

Promise.race([p5, p6])
.then(function(value) {
// Not called
}, function(error) {
console.log(error.message); // "six"
// p6 is faster, so it rejects
});  