// Promise-ի finally() մեթոդը պլանավորում է ֆունկցիա՝ հետ կանչելու գործառույթը, որը պետք է կանչվի, երբ խոստումը կարգավորվի:
function checkMail() {
    return new Promise((resolve, reject) => {
      if (Math.random() > 0.5) {
        resolve('Mail has arrived');
      } else {
        reject(new Error('Failed to arrive'));
      }
    });
  }
  
  checkMail()
    .then((mail) => {
      console.log(mail);
    })
    .catch((err) => {
      console.error(err);
    })
    .finally(() => {
      console.log('Experiment completed');
    });
  