// Promise.any() methody ancnelov bolor promise-neri vrayov veradarznuma miayn amenaarajin ardyunq tvac drakan(resolved) promise-y, isk ete miayn bacasakana(rejected), uremn veradarcnuma AggregateError ev asuma vor voch mi drakan ardyunqov promise chka
// Example 1
const promise1 = Promise.reject(0);
const promise2 = new Promise((resolve) => setTimeout(resolve, 100, 'quick'));
const promise3 = new Promise((resolve) => setTimeout(resolve, 500, 'slow'));

const promises = [promise1, promise2, promise3];

Promise.any(promises).then((value) => console.log(value));

// expected output: "quick"


// Example 2
const prErr = new Promise((resolve, reject) => {
    reject("Always fails");
  });
  
  const pSlow = new Promise((resolve, reject) => {
    setTimeout(resolve, 500, "Done eventually");
  });
  
  const pFast = new Promise((resolve, reject) => {
    setTimeout(resolve, 100, "Done quick");
  });
  
  Promise.any([prErr, pSlow, pFast]).then((value) => {
    console.log(value);
    // pFast fulfills first
  })
  // expected output: "Done quick"


// Example 3
const pErr = new Promise((resolve, reject) => {
    reject('Always fails');
  });
  
  Promise.any([pErr]).catch((err) => {
    console.log(err);
  })
  // expected output: "AggregateError: No Promise in Promise.any was resolved"