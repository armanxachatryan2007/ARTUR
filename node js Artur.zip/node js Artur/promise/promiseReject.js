// Promise.reject(reason) == xostum method(patchar), vory veradarcnum e Promise, vory merjvel e mer grac PATCHARov(reason)
// Example 1
Promise.reject(new Error("провал")).then(function(success) {
    // not called
  }, function(error) {
    console.log(error); // expected "провал" + Stacktrace
    throw error; // повторно выбрасываем ошибку, вызывая новый reject
  });


// Example 2
function resolved(result) {
    console.log('Resolved');
  }
  
  function rejected(result) {
    console.error(result);
  }
  
  Promise.reject(new Error('fail')).then(resolved, rejected);
  // expected output: Error: fail