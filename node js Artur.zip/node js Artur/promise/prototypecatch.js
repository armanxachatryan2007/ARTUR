// Catch() մեթոդը վերադարձնում է Promise և վերաբերում է միայն մերժված դեպքերին:
const promise1 = new Promise((resolve, reject) => {
    throw 'Uh-oh!';
    // reject('Uh-oh!'); // nuynna inchvor throw
  });
  
  promise1.catch((error) => {
    console.error(error);
  });
  // expected output: Uh-oh!