// Promise.resolve(value) մեթոդը վերադարձնում է խոստում, որը բավարարված է փոխանցված արժեքով:
// Example 1
const promise1 = Promise.resolve(123);

promise1.then((value) => {
  console.log(value);
  // expected output: 123
});


// Example 2
const p = Promise.resolve([1,2,3]);
p.then((v) => {
  console.log(v[0]); // 1
});



// Example 3
const original = Promise.resolve(33);
const cast = Promise.resolve(original);
cast.then((value) => {
  console.log('value: ' + value);
});
console.log('original === cast ? ' + (original === cast));

// logs, in order:
// original === cast ? true
// value: 33
