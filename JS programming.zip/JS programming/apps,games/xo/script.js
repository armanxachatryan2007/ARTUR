'use strict';

window.onload = function () {
    for (let i = 0; i < 9; i++) {
        document.getElementById('mainBlock').innerHTML += `<div class="block"></div>`;

    }

    let a = 0;
    document.getElementById('mainBlock').onclick = function () {
        if (event.target.className === 'block') {
            if (a % 2 == 0) {
                event.target.innerHTML = 'X'
            } else {
                event.target.innerHTML = 'O'
            }
            a++;
            win();
        }

    }

    const win = function () {
        var index = document.getElementsByClassName('block');
        if (index[0].innerHTML == 'X' && index[1].innerHTML == 'X' && index[2].innerHTML == 'X') {
            alert('x wins')
        }else if (index[3].innerHTML == 'X' && index[4].innerHTML == 'X' && index[5].innerHTML == 'X') {
            alert('x wins')
        } else if (index[6].innerHTML == 'X' && index[7].innerHTML == 'X' && index[8].innerHTML == 'X') {
            alert('x wins')
        } else if (index[0].innerHTML == 'X' && index[3].innerHTML == 'X' && index[6].innerHTML == 'X') {
            alert('x wins')
        } else if (index[1].innerHTML == 'X' && index[4].innerHTML == 'X' && index[7].innerHTML == 'X') {
            alert('x wins')
        } else if (index[2].innerHTML == 'X' && index[5].innerHTML == 'X' && index[8].innerHTML == 'X') {
            alert('x wins')
        } else if (index[0].innerHTML == 'X' && index[4].innerHTML == 'X' && index[8].innerHTML == 'X') {
            alert('x wins')
        } else if (index[2].innerHTML == 'X' && index[4].innerHTML == 'X' && index[6].innerHTML == 'X') {
            alert('x wins')
        }
        else if (index[0].innerHTML == 'O' && index[1].innerHTML == 'O' && index[2].innerHTML == 'O') {
            alert('O wins')
        } else if (index[3].innerHTML == 'O' && index[4].innerHTML == 'O' && index[5].innerHTML == 'O') {
            alert('O wins')
        } else if (index[6].innerHTML == 'O' && index[7].innerHTML == 'O' && index[8].innerHTML == 'O') {
            alert('O wins')
        } else if (index[0].innerHTML == 'O' && index[3].innerHTML == 'O' && index[6].innerHTML == 'O') {
            alert('O wins')
        } else if (index[1].innerHTML == 'O' && index[4].innerHTML == 'O' && index[7].innerHTML == 'O') {
            alert('O wins')
        } else if (index[2].innerHTML == 'O' && index[5].innerHTML == 'O' && index[8].innerHTML == 'O') {
            alert('O wins')
        } else if (index[0].innerHTML == 'O' && index[4].innerHTML == 'O' && index[8].innerHTML == 'O') {
            alert('O wins')
        } else if (index[2].innerHTML == 'O' && index[4].innerHTML == 'O' && index[6].innerHTML == 'O') {
            alert('O wins')
        }
    }
}
