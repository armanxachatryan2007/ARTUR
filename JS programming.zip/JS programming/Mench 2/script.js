// Xndir 1
// let a = 10;
// let b = 3;
// let c = a % b;

// Xndir 7
// let str = 'abcde';
// alert(str[0]);
// alert(str[2]);
// alert(str[4]);

// Xndir 8
// let str = 'xndir';
// alert(str[4]);

// Xndir 9
// let str = 'lucum';
// alert(str[3]);

// Xndir 10
// let age = prompt('Qani tarekan eq duq?', 21);
// alert('Duq ' + age + ' tarekan eq!');

// let name='Arshak';
// if( name=='Arshak') {
//     console.log('Thank you vor your visit');
// }
// else{ console.log ('You are not Arshak');
// }

// let a=7;
// let b=5;
// let c=18;
// if(a > b){
//     if(a > c){
//         console.log(a);
//     }
//     else{
//         console.log(c);
//     }
// }
// else{
//     if(b > c){
//         console.log(b);
//     }
//     else{
//         console.log(c);
//     }
// }

// Xndir 1
// let a=1;
// // let a=0;
// // let a=-3;
// if (a=0) {
//     console.log("true");
// }
// else {
//     console.log("false");
// }

// Xndir 2
// let a=1
// let a=0
// let a=3
// if (a>0) {
//     console.log("true");
// }
// else {
//     console.log("false")
// }

// Xndir 3
// let a=1
// let a=0
// let a=-3
// if (a<0){
//     console.log("true");
// }
// else{
//     console.log("false");
// }

// Xndir 4
// let a=1
// let a=0
// let a=-3
// if (a>=0){
//     console.log("true");
// }
// else {
//     console.log("false");
// }

// Xndir 5
// let a=1
// let a=0
// let a=-3
// if (a<=0) {
//     console.log("true");
// }
// else{
//     console.log("false");
// }

// Xndir 6
// let a=1
// let a=0
// let a=-3
// if (a!=0) {
//     console.log("true");
// }
// else {
//     console.log("false");
// }

// Xndir 7
// let a="test"
// let a="тест"
// let a=3
// if (a="test") {
//     console.log("true");
// }
// else {
//     console.log("false");
// }

// Xndir 8
// let a="1"
// let a=1
// let a=3
// if (a=="1") {
//     console.log("true");
// }
// else {
//     console.log("false");
// }

// Xndir 9/1
// let test=true;
// // let test=false;
// if (test==true) {
//     console.log("true");
// }
// else {
//     console.log("false");
// }

// Xndir 9/2
// let test = true;
// let test = false;
// test == true ? console.log('true') : console.log('false');

// Xmdir 10/1
// let test=true;
// let test=false;
// if (test!=true) {
//     console.log("true");
// }
// else {
//     consosle.log("false");
// }

// Xndir 10/2
// let test=true;
// let test=false;
// test!=true ? console.log("true") : console.log("false");

// alert('Hello');
// let mail=prompt('greq dzer mail');
// let c=mail[mail.length-4]+mail[mail.length-3]+mail[mail.length-2]+mail[mail.length-1];
// let a=mail[mail.length-3]+mail[mail.length-2]+mail[mail.length-1];
// let b=mail[mail.length-2]+mail[mail.length-1];
//  if(a==='com' || b==='ru'){

// }
// else {
//     alert("Good by");
// }
// if(a==='com'){
//     alert('Welcome')
// }else if (b==='ru'){
// alert('Welcome')
// }else if(){

// }else{
//     alert('Goodbye')
// }

// ax2+bx+c=0
// d= b2-4ac
// x12=-b_+#D/2a

// let a = +prompt('a = ');
// let b = +prompt("b = ");
// let c = +prompt('c = ');
// let d = Math.pow(b, 2) - 4*a*c;
// let x1 = -b + Math.sqrt(d) / 2*a;
// let x2 = -b - Math.sqrt(d) / 2*a;
// if(a,b,c === 0) {
//     console.log('Havasarumy uni 1 armat, vory havasar e 0-i');
// } else if (d < 0) {
//     console.log('Havasarumy armatner chuni');
// } else {
//     console.log('x1 = ', x1, 'x2 = ', x2);
// }

// alert('Hello');
// let hour=(60*60);
// let day=(hour*24);
// let month=(day*30);
// alert(hour);
// alert(day);
// alert(month);

// alert("Hello");
// let a=prompt('Greq jamy');
// if ( a>=8 && a<=12 ) {
//     alert("Bari luys");
// }
// else if ( a >=13 && a<=16) {
//     alert("Bari or");
// }
// else if ( a>=17 && a<=21) {
//     alert('Bari ereko');
// }
// else {
//     alert("Bari gisher");
// }

// alert('Hello');
// let mail=prompt('Write your e-mail.');
// let LastName=prompt('Write your Last Name');
// let age=prompt('How old are you?');
// let a=mail[mail.length-2]+mail[mail.length-1];
// let b=LastName[LastName.length-3]+LastName[LastName.length-2]+LastName[LastName.length-1];
// let c=age>=23;
// if (a === "ru" && b ==="yan") {
//     alert("Welcome")
// }
// else if ( c ) {
//     alert("Welcome");
// }
// else {
//     alert("Good by");
// }

// // d= b2-4ac
// // x12=-b_+#D/2a
// let a = +prompt("a = ");
// let b = +prompt("b = ");
// let c = +prompt("c = ");
// let d = Math.pow(b, 2) - 4*a*c;
// let x1 = -b + Math.sqrt(d) / 2*a;
// let x2 = -b - Math.sqrt(d) / 2*a;
// console.log (x1, x2);

// let p = 1;
// for(i = 1; i<=20; i++) {
//     if(i % 2 != 0)
//     p = p*i;
// }
//     console.log(p);

//     let sum = 0;
//     for(k = 0; k<=20; k++) {
//         if (k % 7 === 0)
//         sum += k;
//     }
//         console.log(sum);

// Xndir 1
// let a = 10;
// let b = 3;
// alert (a % b);

// Xndir 2
// let a = +prompt("Greq A");
// let b = +prompt("Greq B");
// if ( a % b === 0) {
//     alert ('Bajanvuma aranc mnacord, patasxan: ' + a%b)
// }
// else {
//     alert ('Bajanvuma mnacordov, patasxan: ' + a%b);
// }

// Xndir 3
// let st = Math.pow(2, 10);
// alert(st);

// Xndir 4
// let a = Math.round(Math.sqrt(379));
// let b = Math.round(Math.sqrt(379)*10);
// let c = Math.round(Math.sqrt(379)*100);
// alert(a);
// alert(b);
// alert(c);

// Xndir 5
// let a = Math.ceil(Math.sqrt(587));
// let b = Math.floor(Math.sqrt(587));
// alert (a);
// alert (b);

// Xndir 6
// let a = Math.min(4, -2, 5, 19, -130, 0, 10);
// let b = Math.max(4, -2, 5, 19, -130, 0, 10);
// alert (a);
// alert (b);

// Xndir 7
// let a = Math.floor(Math.random()*100) + 1;
// alert (a);

// Xndir 8
// let a = +prompt("Greq A");
// let b = +prompt("Greq B");
// let c = Math.abs(a - b);
// alert(c);

// Xndir 9
// let a = +prompt('a');
// let b = +prompt('b');
// let c = Math.abs(a-b);
// if ((a == 6 || a == 3) && (b == 5 || b == 1)) {
//     alert(c);
// }
// else {
//     alert('hajox');
// }

// let a = [3, 7, 39];
// a.reverse();
//     console.log(a)

// hetevic avelancelu hamar
// let arr = [1, 9, 0, 23];
// arr.push("a", "b", "e");
// document.write(arr);

// demic avelacnelu hamar
// let arr = [1, 9, 0, 23];
// arr.unshift("a", "b", "e");
// document.write(arr);

// hetevic jnjelu hamar
// let arr = [1, 9, 0, 23];
// arr.pop();
// document.write(arr);

// demic jnjelu hamar
// let arr = [1, 9, 0, 23];
// arr.shift();
// document.write(arr);

// sarquma string(tox)
// let arr = [1, 9, 0, 23];
// arr.join();
// document.write(arr);

// sqsuma tpel hetevic
// let arr = [1, 9, 0, 23];
// arr.reverse();
// document.write(arr);

// tpuma x indexic minchev indexy voch neraryal
// let arr = [92, 2, 84, 4, 7];
// let arr1 = arr.slice(3,4);
// document.write(arr1)

// let arr = ["Я", "Учу", "Javscript", "!"];
// let a = arr.join("+");
// document.write(a);

// for (i = 1; i <= 100; i++) {
//     let x = '';
//     if(i%3===0) {
//         x += 'Fizz'
//     }
//     if(i%5===0) {
//         x += 'Buzz'
//     }
//     if(i%5===0 && i%3===0) {
//         x == 'FizzBuzz'
//     }
//     console.log(x || i)
// }

// TNAYIN ARAJADRANQ
// let array = [123, -41, 4, 6, 13, -89, -905, 949];

// for(x=0; x < array.length; x++) {
// for(i=0; i < array.length - 1 - x; i++) {
//     if(array[i] > array[i+1]) {
//         let max = array[i]
//         array[i] = array[i +1]
//         array[i+1] = max
//         }
//     }
// }
// console.log(array)

// let array = [21, 54, -4, -67, 90, 98, 100, -456];
// for (x=0; x<array.length; x++) {
// for (i=0; i<array.length -1 - x; i++){
//     if (array[i] > array[i+1]) {
//         let max = array[i]
//         array[i] = array[i+1]
//         array[i+1] = max
//     }
// }
// }
// console.log(array)
// console.log(array.reverse())

// let array = [21, 54, -4, -67, 90, 98, 100, -456];
// for (x=0; x<array.length; x++) {
//     for (i=0; i<array.length - 1 -x; i++) {
//         if (array[i] > array[i+1]) {
//             let max = array[i];
//             array[i] = array[i+1]
//             array[i+1] = max
//         }
//     }
// }
// console.log(array)

// indexic sksac etel hety qani element toxi
// let str = "abcde";
// let sub = str.substr(1,3);
// console.log(sub);

// inchvor elementic element mejiny hanenq
// let str = "abcde";
// let sub = str.substring(2,3);
// console.log(sub);

// gruma sax toxery irar het kpac mi toxov
// let str1 = 'string1';
// let str2 = 'string2';
// let str3 = 'string3';
// let result = str1.concat(str2,str3);
// console.log(result);

// hanuma mer uzac bari(arajini, ete et bary mi qani angam krknvuma) indexy
// let str = 'Es sovorumem sovorumem JavaScript';
// console.log(str.indexOf('sovorumem'));

// let str = "b..b..b"
// console.log(str.lastIndexOf("g"));

// let str = "     stroka     ";
// console.log(str.trim());

// arr.includes(inchy stugi) ( stuguma ka ardyoq massivi mech qo nshacy )

// Homework

// let str = "abcde";
// let sub = str.substr(-1);
// alert(sub);

// let str = "abcde";
// let sub = str.substr(0, 2);
// alert(sub);

// let str = '025468'
// let a = '-'
// let str1 = str.substring(0,1) + a + str.substring(1,4) + a + str.substring(4,6)
// console.log(str1)

// let mycolor = ['Red', 'Green', 'White', 'Black'];
// let a = mycolor.join(' ')
// console.log(a);

// Xndir 1
// let arr =[2,6,99, true,false,[4,[],88,[6,true,[false,5,[0,156,'hello'[false,4,7,true,{}]]],undefined],'abc'],"a",['Javascript',['helloWorld',undefined,0],NaN,976,true],'b',7,{}];
// alert(arr[7][0]) // JavaScript
// alert(arr[7][3]) // 976
// alert(arr[7][2]) // NaN
// alert(arr[5][4]) // abc
// alert(arr[10]) // verjin object

// Xndir 2
// let ru = ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];
// let en = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
// document.write(ru[0],' - ruseren',en[2],' - angleren');

// Xndir 3
// let string ="123123"
// for (let i = 0; i < string.length; i++) {
//     let num1 = Number(string[0]) + Number(string[1])  + Number(string[2]);
//     let num2 = Number(string[3]) + Number(string[4]) + Number(string[5]);
//     if ( num1 === num2) {
//     alert("Yes") }
//     else {
//         alert("No");
//     }
// }

// Xndir 4
// let array = [2,3,4,5];
// let artadryal = array[0] * array[1] * array[2] * array[3];
// console.log(artadryal)

// Xndir 5
// let arr = [2,3,-4,-7,5,8];
// let arr1 = [];
// for(i=0; i<arr.length; i++) {
//     if(arr[i]>0) {
//         arr1.push(arr[i]);
//     }
// }
// console.log(arr1);
// let sum = arr1[0] + arr1[1] + arr1[2] + arr1[3];
// console.log(sum);

// Xndir 6
// let str = 'Hello Dear';
// let a = str[0].toUpperCase();
// let b = str[6].toUpperCase();
// let str2 = a + 'ello' + ' ' + b + 'ear';
// console.log(str2);

// Xndir 7
// let array = [190, 23, -54, 998, 2, -87, 75, 98, -8];
// for (x=0; x<array.length; x++) {
// for(i=0; i<array.length - 1- x; i++) {
//     if(array[i] > array[i+1]) {
//         let max = array[i];
//         array[i] = array[i+1];
//         array[i+1] = max;
//     }
// }
// }
// console.log(array);

// Xndir 8
// let a = ['1', '</br>', '333', '</br>','55555', '</br>','7777777', '</br>','999999999'];
// document.write(a);

// Xndir 9
// let a = ['xxxxx', '</br>', 'xxxx', '</br>','xxx', '</br>','xx', '</br>','x'];
// document.write(a);

// Xndir 10
// let a = +prompt();
// let b = +prompt();
// let c = [1,2,3,4,5,6,7,8,9,10];
// let y;
// for  (i = 0; i<=c.length - 1; i++) {
//     if (a%c[i] === 0 && b%c[i] === 0) {
//         y=c[i]
//     }
// }
// document.write(y)

// Xndir 11
// let arr = [];
// arr.push(Math.max(2,3,4,5));
// arr.unshift(Math.min(2,3,4,5));
// document.write(arr);

// Xndir 13
// let arr = [0,9,9,7,6,6];
// arr.sort();
// let arr1 = [];
// for(i=0; i<arr.length;i++) {
//     if(arr[i] === arr[i+1]) {
//         arr1.push(arr[i]+arr[i+1]);
//     }
// }
// console.log(arr1[0]+arr1[1]);

// function toNum(amount, combination) {
//     let b = [];
//     if(amount<= 0 || !combination.length) {
//         return false;
//     }
//     for(let i = 0; i <combination.length; i++) {
//         if(amount >= combination[i]) {
//             let res = Math.floor(amount/combination[i]);
//             amount = amount - res * combination[i];
//             for(let j = 0; j < res; j ++) {
//                 b.push(combination[i]);
//             }
//         }
//     }
//     return b;
// }
// console.log(toNum(76, [25, 10, 5,2,1]));

// Write a JavaScript function that accept a list of country names as input and returns the longest country name as output
// Sample function : Longest_Country_Name(["Australia", "Germany", "United States of America"])
// Expected output : "United States of America"
// function Longest_Country_Name (array){
// let max = array[0];
// for(let i = 1; i<array.length; i++) {
//     if(array[i].length > max.length) {
//         max = array[i];
//     }
// }
// return max;
//   }
// console.log(Longest_Country_Name(["Australia", "Germany", "United States of America"]));

// Write a JavaScript function to find the first not repeated character.
// Sample arguments : 'abacddbec'
// Expected output : 'e'
// function Find_Not_Repeated_Character (string) {
//     let array = string.split('');
//     array.sort();
//     for(let i = 0; i<array.length; i++) {
//         if(array[i]===array[i+1]) {
//             delete(array[i]);
//             delete(array[i+1]);
//         }
//     }
//     return array.join('');
// }
// console.log(Find_Not_Repeated_Character('abacddbec'));

// Write a JavaScript function to get all possible subset with a fixed length (for example 2) combinations in an array.
// Sample array : [1, 2, 3] and subset length is 2
// Expected output : [[2, 1], [3, 1], [3, 2]]
// function randomZuyg(qanak, array) {
// array.sort();
// let arr1 = [];
// let arr2 = [];
// let arr3 = [];
// let result = [];
//      if(qanak === 2 && array.length === 3) { 
//             arr1.push(array[1],array[0]);
//             arr2.push(array[2],array[0]);
//             arr3.push(array[2],array[1]);
//             result.push(arr1,arr2,arr3);
//         }
//     return result;
// }
// console.log(randomZuyg(2,[1,2,3]));

// function tivyGriHakarak (x) {
//     x += '';
//     return Number(x.split('').reverse().join(''));
// }
// console.log(tivyGriHakarak(32243));

// function shariAlfavitov (string) {
// return string.split('').sort().join('');
// }
// console.log(shariAlfavitov('webmaster'));

// function Gti_Amenamecic_MihatQich_U_Amenapoqric_MihatMec(array) {
//   let array1 = [];
//   array.sort().pop();
//   array.sort().shift();
//   array1.push(array.shift());
//   array1.push(array.pop());
//   return array1.join(",");
// }
// console.log(Gti_Amenamecic_MihatQich_U_Amenapoqric_MihatMec([1, 2, 3, 4, 5]));

// function Tvi_Astichan(number, pow) {
//   let a = 1;
//   for (let i = 1; i <= pow; i++) {
//     a = a * number;
//   }
//   return a;
// }
// console.log(Tvi_Astichan(3, 3));

// function Toxel_Toxi_Mej_Amen_Taric_Mi_Hat(string) {
//   let array = string.split("");
//   array.sort();
//   for (let i = 0; i < array.length; i++) {
//     if (array[i] === array[i + 1]) {
//       delete array[i];
//     }
//   }
//   return array.join("");
// }
// console.log(Toxel_Toxi_Mej_Amen_Taric_Mi_Hat("thequickbrownfoxjumpsoverthelazydog"));

// function Veradardzru_RandomTiv_Esinchic_Esinch(min, max) {
//   return Math.random() * (max - min) + min;
// }
//   console.log(Veradardzru_RandomTiv_Esinchic_Esinch(1,3));

// function Veradardzru_RandomTiv_Esinchic_Esinch_VerjinyChhashvac(min, max) {
//   min = Math.ceil(min);
//   max = Math.floor(max);
//   return Math.floor(Math.random() * (max - min) + min);
// }
// console.log(Veradardzru_RandomTiv_Esinchic_Esinch_VerjinyChhashvac(1, 3));

// let a = 10;
// let b = 3;
// console.log(a/b);

// let a = +prompt('a');
// let b = +prompt('b');
// if(a%b===0) {
//     console.log('A-n bajanvuma b-i');
// }
// else {
//     console.log('A-n bajanvuma b-i mnacordov');
// }

// let st = Math.pow(2,10);
// let a = Math.sqrt(245);
// let array = [4,2,5,19,13,0,10];
// let sum = 0;
// for(let i = 0; i<array.length; i++) {
//     sum += array[i];
// }
// console.log(st,a,Math.sqrt(sum));

// let a = 379;
// let b = Math.sqrt(a);
// console.log(b.toFixed(0),b.toFixed(1),b.toFixed(2));
// let c = Math.sqrt(587);
// let object = {
//     kloracracDepiPoqr: Math.floor(c),
//     kloracracDepiMec: Math.ceil(c)
// }
// console.log(object);

// console.log(Math.max(4,-2,5,19,-130,0,10), Math.min(4,-2,5,19,-130,0,10));

// console.log((Math.random() * 100) + 1);

// let b = [];
// for(let i = 1; i<=10; i++) {
//     b.push(Math.floor(Math.random()* 100)) + 1;
// }
// console.log(b);

// let a = +prompt('a');
// let b = +prompt('b');
// alert(Math.abs(a-b));

// let arr = [12,15,20,25,59,79];
// let b = 0;
// for(let i = 0; i<arr.length; i++) {
//     b += arr[i]
// }
// console.log(b/arr.length);

// let number = +prompt('number');
// if(number < 0) {
//     console.log('error');
// }
// else if(number === 0) {
//     console.log('factorial is 1');
// }
// else {
//     let factorial = 1;
//     for(let i = 1; i<=number; i++) {
//         factorial *= i;
//     }
//     console.log(factorial);
// }

// let str = 'aaa@bbb@ccc';
// console.log(str.replace(/@/g, '!')); // g = global // veracum enq @-!

// let str = 'aaa bbb ccc';
// console.log(str.substr(4,3), str.substring(4,7), str.slice(4,7));
// substr - vortexic qani hat ktrel
// substring - vortexic vortex ktrel, verjinnel hety
// slice - vortexic vortex ktrel, verjinnel hety

// let date = '2025-12-31';
// let arr = date.split('-');
// let newStr = arr[2] + '-' + arr[1] + '-' + arr[0];
// console.log(newStr);

// let str = 'js';
// let str1 = 'JS';
// console.log(str.toUpperCase(), str1.toLowerCase());

// let str = 'es sovorumem javascript!';
// console.log(str.length);
// let str1 = 'es sovorumem javascript!';
// console.log(str1.substr(3,9), str1.substring(3,12), str1.slice(3,12));
// console.log(str1.substr(13,10), str1.substring(13,23), str1.slice(13,23));
// let str2 = 'es sovorumem javascript';
// console.log(str2.indexOf('sovorumem'));

// let str = 'Barev dzez';
// let n = +prompt('n');
// if(str.length >= n) {
//     result = str.substr(0,n) + '...';
//     console.log(result);
// }
// else {
//     result = str;
//     console.log(result);
// }

// let str = 'Es-sovorumem-javascript!';
// console.log(str.replace(/-/g, '!'));

// let str = 'Es sovorumem javascript!';
// console.log(str.split(''));;

// let date = '2025-12-31';
// let arr = date.split('-');
// let newDate = arr[2] + '.' + arr[1] + '.' + arr[0];
// console.log(newDate);

// let arr = ['Es', 'sovorumem', 'javascript', '!'];
// console.log(arr.join('+'));

// let str = 'barev';
// let a = str[0].toUpperCase();
// let b = str.substr(1,5);
// let newStr = a+b;
// console.log(newStr);

// let str = 'barev dzez';
// let a = str[0].toUpperCase();
// let b = str[6].toUpperCase();
// let c = str.substr(1,5);
// let d = str.substr(7,10);
// console.log(a+c+b+d);

// let str = 'var_test_text';
// let a = str[4].toUpperCase();
// let b = str[9].toUpperCase();
// let newStr = str[0]+str[1]+str[2]+str[3]+a+str[5]+str[6]+str[7]+str[8]+b+str[10]+str[11]+str[12];
// console.log(newStr.replace(/_/g, ''));

// function reverse_a_number (n) {
//     n += '';
//     return Number(n.split('').reverse().join(''));
// }
// console.log(reverse_a_number(258961));

// function nayi_ardyoq_et_bary_hetuaraj_kardacvuma_nuyndzev_te_che(str) { // tenc barery kochvumen Polindrome
//     if(str === str.split('').reverse().join('')) {
//         console.log('Es toxy polindrome e');
//     }
//     else {
//         console.log('Sxal e, sa polindrome tox chi')
//     }
//     return str;
// }
// console.log(nayi_ardyoq_et_bary_hetuaraj_kardacvuma_nuyndzev_te_che('that'));

// function alphabet_order(str) {
//     return str.split('').sort().join('');
// }
// console.log(alphabet_order('alphabetical'));

// function dzaynavorneri_qanak(str) {
//     let dzaynavorneriList = 'aueioAUEIO';
//     let dzaynqanak = 0;
//     for(let i = 0; i<str.length; i++) {
//         if(dzaynavorneriList.indexOf(str[i]) != -1) {
//             dzaynqanak += 1;
//         }
//     }
//     return dzaynqanak;
// }
// console.log(dzaynavorneri_qanak('barev dzez'));

// function tivy_hasarak_e_te_voch(number) { // hasarak ena vor bajanvuma menak 1-i u ira vra
//     if(number===1) {
//         return false;
//     }
//     else if(number===2) {
//         return true;
//     }
//     else {
//         for(let i = 2; i < number; i++) {
//             if(number % i === 0) {
//                 return false;
//             }
//         }
//         return true;
//     }
// }
// console.log(tivy_hasarak_e_te_voch(17));

// function matrix(n) {
//     for(let i = 0; i < n; i++) {
//         for(let j = 0; j < n; j++) {
//         if(i===j) {
//             document.write(' 1 ');
//         }
//         else {
//             document.write(' 0 ');
//         }
//         }
//         document.write('</br>');
// }
//         return n;
// }
// console.log(matrix(4));

// function sorting(arr) {
//     for(let i = 0; i < arr.length; i++) {
//         for(let j = 0; j < arr.length - 1 - i; j++) {
//             if(arr[j]>arr[j+1]) {
//                 let max = arr[j];
//                 arr[j] = arr[j+1];
//                 arr[j+1] = max;
//             }
//         }
//     }
//     return arr;
// }
// console.log(sorting([1,10,89,0,4]));
// function second_greatest_lowest(arr) {
//     sorting(arr);
//     let arr1 = [];
//     arr1.push(arr[0+1], arr[arr.length-2]);
//     return arr1;
// }
// console.log(second_greatest_lowest([8,9,10,11,12]));

// function is_perfect(number) { // idelakan e tivy te voch, idelakan tivy ena vory havasara en tveri gumarin voronc vor inqy bajanvuma aranc mnacord
//     let sum = 0;
//        for(let i=1; i <= number/2; i++) {
//              if(number % i === 0) {
//                 sum += i;
//               }
//          }
//          if(sum === number && sum != 0) {
//            document.write("Это идеальное число.");
//             }
//           else {
//            document.write("Это не идеальное число.");
//             }
//      }
//     is_perfect(6);

// function bazmapatikner(number) {
//     let arr = [];
//     for(let i = 1; i <= number; i++) {
//         if(number % i === 0) {
//             arr.push(i);
//         }
//     }
//     return arr;
// }
// console.log(bazmapatikner(20));

// function amount_coins(amount,coins) {
//   let a = [];
//   if(amount <= 0 || !coins.length) {
//       return false;
//   }
//   for(let i = 0; i<coins.length; i++) {
//       if(amount >= coins[i]) {
//           let res = Math.floor(amount / coins[i]);
//           amount = amount - res * coins[i];
//           for(let j = 0; j<res; j++) {
//               a.push(coins[i]);
//           }
//       }
//   }
//   return a;
// console.log(amount_coins(43,[25,10,5,2,1]));

// function pow(b,n) {
//     let a = 1;
//     for(let i = 1; i <= n; i++) {
//         a *= b;
//     }
//     return a;
// }
// console.log(pow(3,4));

// function findLeiterInWord(leiter,word) {
//     // word.split('').sort();
//     let array = [];
//     for(let i = 0; i<word.length; i++) {
//         if(word.charAt(leiter) && word[i]===leiter) {
//             array. push(leiter);
//         }
//     }
//     return array.length;
// }
// console.log(findLeiterInWord('j', 'jjpjitj'));

// function generateRandomStr(erkarutyun) {
//     let a = '';
//     let strlist = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
//     for(let i = 0; i<erkarutyun; i++) {
//         if(erkarutyun<=strlist.length) {
//         a += strlist.charAt(Math.floor(Math.random()*strlist.length));
//         }
//     }
//     return a;
// }
// console.log(generateRandomStr(63));

// OBJECTS AND METHODS OF OBJECTS

// const target = { a: 7, b: 2};
// const source = { b: 4, c: 5 };
// console.log(Object.assign(target, source)); // erku objectnery vercnuma u arajin objecty poxuma erkrordov, ira meji key-ernel, isk ete arajinum ka et key-y, isk erkrordum chka et key-na qcum erkrord

// const entries = [ ['foo', 'bar'], ['baz', 42] ];
//   const obj = Object.fromEntries(entries); // fromEntries - hakarak array-ic sarquma object
//   console.log(obj); // { foo: "bar", baz: 42 }

// const object1 = {
//     a: 1,
//     b: 2,
//     c: 3
//   };
// // console.log(Object.getOwnPropertyNames(object1)); //  ["a", "b", "c"] // objecti key-ery qcuma array-i mej u amen mi key array-i mi elementa darnum

// let person = {
//     name: 'Jon',
//     age: 45,
//     location: "Berlin",
//     email: "safasf@mail.com",
// }
// console.log(person)

// console.log(Object.isSealed(person)); // harcnuma ardyoq seal araca qo object-y u veradardznuma true kam false
// console.log(Object.seal(person)); // objecty pechatuma, du karas ira mej popoxutyun katares bayc ches kara ira mejic ban hanes
// console.log(Object.isExtensible(person)); // asuma karas ardyoq du es object-i het ashxates, ira mej popoxutyunner katares, veradardznuma mez true kam false
// console.log(Object.preventExtensions(person)); // es method-y greluc heto du ches kara tvyal object-i mej popoxutyun katares
// console.log(Object.is('1','2')); // false // harcnuma yndhanrapes es gract tarreric 1-y nuyn 2-rdna te che
// console.log(Object.keys(person).length); // 4 // hashvuma objectum key-eri qanaky
// console.log(Object.values(person).length); // 4 // hashvuma objectum value-eri qanaky
// console.log(person.hasOwnProperty('name')); // true // ka tenc ban object-i mej te che
// console.log(Object.entries(person)); // amen key u value irar het arandzin array-i meja qcum et arraynerne mihat urish array-i mej
// console.log(Object.isFrozen(person)); // harcnuma ardyoq sarecvaca qo object-y u veradardznuma mez true kam false
// console.log(Object.freeze(person)); // sarecnuma u ches kara du et objecti mej popoxutyun anes el
// console.log(Object.values(person)); // sarquma array u dra mej qcuma objecti value-nery
// console.log(Object.keys(person)); // sarquma array u dra mej qcuma objecti key-ery

// // for(let key in person) {
// //     console.log(key)
// // } // key

// // for(let key in person) {
// //     console.log(person[key])
// // } // value

// // for(let key of Object.keys(person)) {
// //     console.log(person[key])
// // } // value

// for(let key of Object.keys(person)) {
//     console.log(key)
// } // key

// let person = {
//     a: 1,
//     b: 2,
//     c: 3,
// }
// let person1 = {}
// for(let key in person) {
// person1[person[key]] = key
// }
// console.log(person1);

// let x = ['a','b','a','a','c','b'];
// let person = {
//     a: 0,
//     b: 0,
//     c: 0,
// }
// for(let i = 0; i < x.length; i++) {
//     person[x[i]]++;
// }
// console.log(person);

// let library = [
//     {
//         title: 'Bill Gates',
//         author: 'The Road Ahead',
//         readingStatus: true
//     },
//     {
//         title: 'Steve Jobs',
//         author: 'Walter Isaacson',
//         readingStatus: true
//     },
//     {
//         title: 'Mockingjay: The Final Book of The Hunger Games',
//         author: 'Suzanne Collins',
//         readingStatus: false
//     }];
// for (let i = 0; i < library.length; i++) {
//     let book = '<<' + library[i].title + '>>' + ' by ' + library[i].author;
//     if (library[i].readingStatus) {
//       console.log("Already read " + book);
//     } else
//     {
//      console.log("You still need to read " + book);
//     }
//    }

// let personsSalary = {
//     'Nikolay':'1000',
//     'Vasiliy':'500',
//     'Peter':'200'
// };
// let arr = Object.entries(personsSalary);
// document.write(arr[2][0] + ' salary is ' + arr[2][1] + '</br>' + arr[0][0] + ' salary is ' + arr[0][1]);

// Const
// const arr = ['a', 'b', 'c'];
// arr[1] = '!';
// console.log(arr); // ['a', '!', 'c']

// const arr = ['a', 'b', 'c'];
// arr = [1, 2, 3];
// console.log(arr); // chi ashxati, chenq kara poxenq vortev inqy hastatuna

// const arr = ['a', 'b', 'c'];
// arr = ['a', 'b', 'c'];
// console.log(arr); // chi ashxati

// const PI = 3.141592653589793;
// PI = 3.14;      // This will give an error
// PI = PI + 10;   // This will also give an error

// // You can create a const object:
// const car = {type:"Fiat", model:"500", color:"white"};
// // You can change a property:
// car.color = "red";
// // You can add a property:
// car.owner = "Johnson";

// const car = {type:"Fiat", model:"500", color:"white"};
// car = {type:"Volvo", model:"EX60", color:"red"};    // ERROR

// Object
// const myCar = new Object();
// myCar.make = 'Ford';
// myCar.model = 'Mustang';
// myCar.year = 1969;
// console.log(myCar); // veradardznelua mer nor objecty

// let obj = {
//     a:1,
//     b:2,
//     c:3
// };
// delete(obj.b);
// console.log(obj); // {a:1, c:3};

// const Manager = {
//     name: "John",
//     age: 27,
//     job: "Software Engineer"
//   }
//   const Intern = {
//     name: "Ben",
//     age: 21,
//     job: "Software Engineer Intern"
//   }
//   function sayHi() {
//     console.log(`Hello, my name is ${this.name}`) // this-y uxaki grumenq vor dran karananq tanq en objecty vory uzum enq
//   }
//   // add sayHi function to both objects
//   Manager.sayHi = sayHi;
//   Intern.sayHi = sayHi;
//   Manager.sayHi(); // Hello, my name is John'
//   Intern.sayHi(); // Hello, my name is Ben'
// function howOldAmI() {
//     console.log(`I am ${this.age} years old.`);  // this-y uxaki grumenq vor dran karananq tanq en objecty vory uzum enq
//   }
//   Manager.howOldAmI = howOldAmI;
//   Manager.howOldAmI(); // I am 27 years old.

// const person = {fname:"John", lname:"Doe", age:25};
// let text = "";
// for (let x in person) {
//   text += person[x];
// }
// console.log(text); // JohnDoe25

// const cars = ["BMW", "Volvo", "Mini"];
// let text = "";
// for (let x of cars) {
// text += x;
// }
// console.log(text); // BMWVolvoMini

// let arr = ['a', 'b', 'c', 'd', 'e'];
// let arr1 = ['1', '2', '3', '4', '5'];
// const arr2 = new Object();
// for (i=0; i<arr1.length; i++){
//     arr2[`${arr1[i]}`] = `${arr[i]}`;
// }
// console.log(arr2);

// let obj = {
//     1: 125,
//     2: 225,
//     3: 128,
//     4: 356,
//     5: 452
// };
// let arr = [];
// for(let values in obj) {
//     let x = String(obj[values]);
//     if(x[0] == '1' || x[0] == '2') {
//         arr.push(x);
//     }
// }
// console.log(arr);

// let obj = {
//     'a': 12,
//     'b': 21,
//     'c': 13,
//     'd': 33
// };
// let obj1 = new Object();
// for(let values in obj) {
//     if(obj[values] >= 10 && obj[values] <= 20) {
//      obj1[`${values}`] = `${obj[values]}`   
//     }
// }
// console.log(obj1);

// let arr = ['1','2','3']
// for(i = 0; i < arr.length; i++){
//     alert(arr[i]);
// }

// let arr = ['1','2','3']
// for(i = 0; i < arr.length - 1; i++){
//     alert(arr[i] + arr[i+1]);
// }

// let lines = 7;
// let str = '';
// let a = '#';
// for(let i = 0; i<lines; i++) {
//     str += a;
//     console.log(str); 
// }

// for(let i = 1; i<=100; i++) {
//     if(i % 3 === 0) {
//         console.log('Fizz');
//     }
//     else if(i % 5 === 0) {
//         console.log('Buzz');
//     }
//     else if(i % 5 === 0 && i % 3 === 0) {
//         console.log('FizzBuzz')
//     }
//     else {
//         console.log(i);
//     }
// }

// let full = ' # # # # ';
// for (let i = 0; i < 8; i++) {
//    console.log(full.substr(i%2,8));
// }

// function checkmin(a,b) {
//     if(a<b) {
//         return a;
//     }
//     else if(a===b) {
//         return 'havasar en';
//     }
//     else {
//         return b;
//     }
// }
// console.log(checkmin(-10, -10));

// function isEven(number) {
//     if(number % 2 === 0) {
//         return true;
//     }
//     else {
//         return false;
//     }
// }
// console.log(isEven(2))

// function range(number,to,plus) {
//     let arr = [];
//     if(number>to, !plus) {
//         for(let i = number; i>=to; i--){
//             arr.push(i);
//         }
//     }
//     if(number<to, !plus) {
//         for(let i = number; i<=to; i++){
//             arr.push(i);
//         }
//     }
//     else if(number>to, plus) {
//         for(let i = number; i>=to; i+=plus) {
//             arr.push(i);
//         }
//     }
//     else if(number<to, plus) {
//         for(let i = number; i<=to; i+=plus) {
//             arr.push(i);
//         }
//     }
//     return arr;
// }
// console.log(range(5,2,-1));
// function sum(arr) {
//     let sum = 0;
//     for(let i = 0; i<arr.length; i++) {
//     sum += arr[i];
//     }
//     return sum;
// }
// console.log(sum(range(1,10)));

// function checkObject(obj1, obj2) {
//     if(typeof obj1 == typeof obj1) {
//         if(typeof obj1 == "object" && obj1 != null) {
//             let equal = true;
//             for(let key in obj1) {
//               if (obj1.hasOwnProperty(key) && obj2.hasOwnProperty(key)) {
//                 if (!checkObject(obj1[key], obj2[key])) {
//                   equal = false;
//                 }
//               } else {
//                 equal = false;
//               }
//             }
//             return equal;
//         } else {
//             return obj1 === obj2;
//         }
//     } else {
//         return false;
//     }
// }
// let object = {
//     a:1,
//     b:2
// };
// let object1 = {
//     a:1,
//     b:2
// };
// console.log(checkObject({a:1, b:2}, {a:1, b:3}));
// console.log(checkObject(object, {a:1, b:2}));
// console.log(checkObject(object1,object));
// console.log(checkObject(object1, {a:1,b:3}));
// console.log(checkObject({a:1, b:2},{a:1,b:2}));

// let arrays = [[1,2,3],[4,5],[6]];
// console.log(arrays[0].concat(arrays[1]).concat(arrays[2]));

// 'use strict';
// const private = 31; // error with 'use strict'
// const interface = 'Audio'; // error with 'use strict'
// let private = 31; // error with 'use strict'
// let interface = 'Audio'; // error with 'use strict'

// forEach - mejy karas dnes menak function, vory uni kodavorvac 3 baxkacucich mas - elem kam value, index, arr(kam en inchi het vor ashxatum enq), chenq kara baxkacucich maseri texery xarnenq, dranq hastat en
// orinak
// let arr = ['first element', 'second element', 77, true, undefined];
// arr.forEach(function(elem,index,arr) {
//     console.log(elem);
//     // console.log(index);
//     // console.log(arr);
// }) 

// let arr = [1,2,3,4,5];
// let sum = 0;
// arr.forEach(function(elem) {
//     sum += elem;
// });
// console.log(sum);

// filter - filtrum-a array-y(kam urish ban),u qcuma array-i mej, ira mej eli neraruma function() u karanq gorc unenanq function-i baxkacucich maseri het(value/elem, index, arr)
// orinak
// let numbers = [-2,55,865,2,-9,63];
// let result = numbers.filter(function(elem) {
//     if(elem<=0){
//         return true;
//     }else{
//         return false;
//     }
// });
// console.log(result);

// let arr = [1,2,3,4,5];
// let result = arr.filter(function(elem){
//     return elem % 2 == 0;
// });
// console.log(result);

// map-y ashxatuma array-i(kam urish bani)meji bolor elementneri het,u qcuma array-i mej, ira mej eli neraruma function() u karanq gorc unenanq function-i baxkacucich maseri het(value/elem, index, arr)
// map-y filter-ic tarbervuma nranov, vor filter-y baci filtreluc urish gorcoxutyun chi anum, isk map-y kara bolor elementneri het cankacac gorcoxutyun ani
// orinak
// let arr = [5,77,98,34,654];
// let result = arr.map(function(elem){
//     return elem*2;
// })
// console.log(result);

// Xndir - '123456' es toxy sarqi senc '214365'
// function a(string) {
//     let arr = string.split('');
//     let b = '';
//     for(let i = 1; i<arr.length; i+=2) {
//         b += arr[i] + arr[i-1];
//     }
//     return b;
// }
// console.log(a('123456'));

// const input = 'George Raymond Richard Martin';
// let a = '';
// a += input.split(' ').map(function(word) {
//     return word[0];
// }).join('');
// console.log(a);
// // console.log(input.split(' ').map(word=>word[0]).join('')); // arrow function

// let arr = [1,2,3,4,5];
// let arr1 = arr.join('').split('');
// let result = arr1.map(function(elem,index){
//    return elem + '*' + index;
// });
// console.log(result);

// let arr = [1,7,0,2,14,6763,42,5];
// let result = arr.filter(function(elem){
//     if(elem>=5) {
//         return true;
//     } else {
//         return false;
//     }
// });
// console.log(result);
// kam
// let result = arr.filter(function(elem){
//     return elem>=5;
// });
// console.log(result);

// let arr = [1,4,36,77,94,2,9];
// let result = arr.map(function(elem){
//     return Math.sqrt(elem);
// });
// console.log(result);

// let arr = ['barev','hajox','qani','tarekan','es'];
// let result = arr.map(function(elem){
//     return elem.split('').reverse().join('');
// });
// console.log(result);

// let arr = ['barev','hajox','qani','tarekan','es'];
// let result = arr.map(function(elem){
//     return elem + '!';
// });
// console.log(result);

// let arr = ['123','456','789'];
// let arr1 = [];
// let result = arr.map(function(elem,index,arr){
//     let a = elem.split('').join();
//     return a.split();
// });
// console.log(result);

// let arr = [41,53,1,35,7,8];
// let sum = 0;
// let result = arr.forEach(function(elem) {
//     sum += Math.pow(elem,2);
// });
// console.log(sum);

// let arr = [12,46,43,-34,-63,14,-6];
// let result = arr.filter(function(elem) {
//     if(elem<0) {
//         return true;
//     } else {
//         return false;
//     }
// });
// console.log(result);

// let arr = [12,46,43,-34,-63,14,-6];
// let result = arr.filter(function(elem) {
//     if(elem>0) {
//         return true;
//     } else {
//         return false;
//     }
// });
// console.log(result);

// let arr = [12,4,3,9,0.1,-34,-63,14,-6];
// let result = arr.filter(function (elem){
//     if(elem>0 && elem<10) {
//         return true;
//     } else {
//         return false;
//     }
// });
// console.log(result);

// let arr = ['fahkjhafkj','afj','afjajf2','1f2','fsggg'];
// let result = arr.filter(function(elem){
//     if(elem.length>5) {
//         return true;
//     } else {
//         return false;
//     }
// });
// console.log(result);

// let arr = [1,2,[3,4],5,[6,7]];
// let result = arr.filter(function(elem){
//     return Number(elem);
// });
// console.log(result);

// let arr = [1,2,-4,3,-10,-5,-8,5];
// let arr1 = [];
// let result = arr.filter(function(elem){
//     if(elem<0) {
//         return arr1.push(elem);
//     } else {
//         return false;
//     }
// });
// console.log(result.length);

// let arr = [1,23,2,14,424,13,5,635];
// let result = arr.filter(function(elem,i){
//     return elem*i<30;
// });
// console.log(result);

// JavaScript Fundamentals – Part 2
// Codding challenge
// Functions 
// function describeCountry(country, capitalCity, population) {
//     return `${country} has ${population} people and its capital city is ${capitalCity}`;
// } 
// console.log(describeCountry('Finland','Helsinki','6 million')); // Finland has 6 million people and its capital city is Helsinki'
// console.log(describeCountry('Armenia','Yerevan','3 million')); // Armenia has 3 million people and its capital city is Yerevan
// console.log(describeCountry('Russia','Moscow','145 million')); // Russia has 145 million people and its capital city is Moscow

// Function Declarations vs. Expressions


// Coding Challenge 1 // 27 page
// function Car(name,speed) {
//     this.make = name;
//     this.speed = speed;
//     this.accelerate = function() {
//         console.log(`${this.speed += 10}km/h`);
//     }
//     this.brake = function() {
//         console.log(`${this.speed -= 5}km/h`);
//     }
// }
// const Car1 = new Car('BMW',120);
// const Car2 = new Car('Mercedes',95);
// Car1.accelerate();
// Car1.brake();
// Car2.accelerate();
// Car2.brake();

// Coding Challenge 2 // 28 page
// class CarCl {
//     constructor(make, speed) {
//         this.make = make;
//         this.speed = speed;
//     }  
//         speedUs() {
//             console.log(`${this.speed *= 1.6}km/h`);
//         }
//         accelerate() {
//             console.log(`${this.speed += 10}km/h`);
//         }
//         brake() {
//             console.log(`${this.speed -= 5}km/h`);
//         }
// };

// const Car3 = new CarCl('Audi',45);
// Car3.speedUs();
// Car3.accelerate();
// Car3.brake();

// Coding Challenge 3 // page 28
// function EV(make,speed,charge) {
//     this.make = make;
//     this.speed = speed;
//     this.charge = charge;
//     this.chargeBattery = function() {
//         console.log(`Charge to ${charge}%`);
//     }
//     this.accelerate = function() {
//         console.log(`${this.make} going at ${this.speed += 20}km/h, with a charge of ${this.charge-=1}%`);
//     }
//     this.brake = function () {
//         console.log(`${this.speed-=10}km/h`);
//     }
// }
// const EV1 = new EV('Tesla', 120, 23);
// EV1.chargeBattery();
// EV1.accelerate();
// EV1.brake();


// Codin Challenge 4 // page 29
// class EVCl {
//     constructor(make,speed,charge) {
//         this.make = make;
//         this.speed = speed;
//         this.charge = charge;
//         this.chargeBattery = function() {
//             console.log(`Charge to ${charge}%`)
//                     }
//         this.accelerate = function() {
//            console.log(` ${this.speed += 20}km/h`);      
//                     }
//     }
//     miasin() {
//         console.log(`${this.make} going at ${this.speed-=20}km/h, with a charge of ${this.charge}%`);
//     }
// }
// const Car4 = new EVCl('Rivian',140, 23);
// Car4.miasin();


// Coding Challenge 1 // page 20
// const poll = {
//     question: "What is your favourite programming language?",
//     options: ["0: JavaScript", "1: Python", "2: Rust", "3: C++"],
//     // This generates [0, 0, 0, 0]. More in the next section!
//     answers: new Array(4).fill(0),
//     registerNewAnswer: function () {
//         let answer = prompt(`${poll.question}`);
//         if (answer && answer <= 3) {
//             poll.answers[answer] += 1
//         }
//     }
//  };
//  function displayResults() {
//     console.log(poll.answers);
//  };

// function qaniHatKaEtBaricStringiMej(str,bar) {
//     let b = bar.length;
//     let sum = 0;
//     for(let i = 0; i<str.length; i++) {
//         if(bar === str.slice(i,b+i)) {
//             sum += 1;
//             i+=b-1;
//         }
//     }
// return sum;
// }
// console.log(qaniHatKaEtBaricStringiMej('ABCABCDELABCFCABC','ABC'));

// Array.every() methody neraruma ira mej function vory uni 3 argument - value/elem,index,arr, ev (this) function-i mej
// Array every() methody nayuma te et function-y vory vor ira mej grel enq chishta array-i bolor elementneri hamar te che u veradardznuma true kam false
// orinak grenq array u nayenq every methodov te ardyoq et array-i bolor elementnery mec en 18-ic, ete ha kberi true ete che false
// let ages = [32, 22,30, 40, 33, 17];
// let ages1 = [30, 40, 50, 60, 19];
// console.log(ages.every(checkAge)); // false, vorovhetev ages array-i mej ka mihat 17 tivy vory mec chi 18-ic
// console.log(ages1.every(checkAge)); // true, vorovhetev array-i bolor elementnery 18-ic mec en
// function checkAge(age) {
//     return age>18;
// }

// Array.findIndex() methody neraruma ira mej function vory uni 3 argument - value/elem, index, arr, ev (this) function-i mej
// Array.findIndex() methody nayuma te et function-y vory vor ira mej grel enq ardyoq hamapatasxanuma array-i elementneric gone mekin u veradardznuma array-i arajin elementi index-y vori hamar function-y chishta, isk ete chka tenc element et array-i mej vori hamar vor function-y chishta veradardznuma -1
// orinak grenq array u nayenq findIndex methodov te et array-i elementneric vorna 18-ic mec u mez kveradardzni arajin elementi index-y vory vor meca 18-ic
// let ages = [3, 10, 19, 20];
// let ages1 = [3, 10, 4, 6];
// console.log(ages.findIndex(checkAge)); // 2 kveradardzni vorovhetev araji tivy vory meca 18-ic 2 indexy uni
// console.log(ages1.findIndex(checkAge)); // -1 kveradardzni vorovhetev chka es array-i mej gone mihat tiv vor 18-ic meca
// function checkAge(age) {
//     return age > 18;
// }

// Array.indexOf() methody nayuma te et array-i meji tvyal elementi index-y vorna u talisa et index-y, isk ete chka tenc element et array-i mej veradarznuma -1
// indexOf methody neraruma ira mej (item, start), aysinqn skzbic nayev karanq grenq te vor elementi index-y ta u te vor index-ic sksi pntrel et elementy
// const fruits = ['Banana', 'Orange', 'Apple', 'Mango'];
// console.log(fruits.indexOf('Apple')); // 2 kberi, vorovhetev fruits array-i mej Apple-y 2-rd index-i taka
// console.log(fruits.indexOf('Cherry')); // -1 kberi, vorovhetev fruits array-i mej  chka Cherry element
// console.log(fruits.indexOf('Apple', 3)); // -1 kberi, vorovhetev 3-rd index-ic sksac chka mer uzac elementy fruits array-um
// console.log(fruits.indexOf('Apple', 1)); // 2 kberi

// Array.lastIndexOf() methody nayuma te et arrayi mej tvyal elementy amenaverjin angam vor index-i tak a grvac
// lastIndexOf methody neraruma ira mej (item, start), aysinqn skzbum nayev karanq grenq te vor elementi index-y ta u te vor index-ic sksi pntrel et amenaverjin elementy
// const fruits = ['Apple', 'Orange', 'Apple', 'Mango'];
// console.log(fruits.lastIndexOf('Apple', -3)); // kveradardzni 0, vorovhetev 3 hat ete verjic jnjenq amenaverjin et elementy 0 indexuma
// console.log(fruits.lastIndexOf('Apple')) // kveradardzni 2, vorovhetev amenaverjin Apple elementy gtnvuma 2 index-i tak

// Array.some() methody neraruma ira mej function vory uni 3 argument - value/elem, index, arr, ev (this) function-i mej
// Array.some() methody nayume te ardyoq array-i meji vorosh elementner(gone meky) function-i hamar chisht en, veradardznuma true kam false
// orinak nayenq te ages array-i mej ka 18-ic barcr tariq 
// const ages = [3, 10, 15, 18];
// const ages1 = [3, 10, 19, 15];
// console.log(ages.some(checkAdult)); // false, vorovhetev chka ages array-i mej 18-ic bardzr tiv
// console.log(ages1.some(checkAdult)); // true, vorovhetev ka gone mek hat 18-ic bardzr tiv ages array-um
// function checkAdult(age) { // Adult nshanakuma chapahas
//     return age > 18;
// }

// Spread syntax
// Spread syntax-y tuyla talis mer function-i mej nerarenq aveli mec mashtabi baner, orinak array,string
// Orinak 1
// function sum(x, y, z) {
//     return x + y + z;
// } 
// const numbers = [1, 2, 3];
// console.log(sum(...numbers)); // 6
// console.log(sum.apply(null, numbers)); // 6 // apply-in function e, vory nerarum e ira mej function.apply(thisArg, [argsArray]), aysinqn inchvor argument u array

// Orinak 2
// function myFunction(a,b,x,y,z) {
//     return (a+b)*(x+y)*z;
// }
// const args = [0, 1];
// console.log(myFunction(-1, 7, ...args, ...[4])); // 24 // -1 u 7 = a u b, ...args = 0 u 1 = x u y, ...[4] = 4 tivy = z
// console.log(myFunction(-1, ...args, 7, ...[5])); // -40 // -1 = a, ...args =  0 u 1 = b u x, 7 = y, ...[5] = 5 tivy = z

// Spread Operator
// Spread Operator-y heshtacnum e sovorakan kody
// Orinak
// 1-in sovorakan dzev
// function myBio(firstName, lastName, company) {
//     return `${firstName} ${lastName} runs ${company}`;
// }
// console.log(myBio('Oluwatobi', 'Sofela', 'CodeSweetly'));
// 2-rd spread operator
// function myBio(firstName, lastName, company) {
// console.log(...['Oluwatobi', 'Sofela', 'runs', 'CodeSweetly']);
// }
// myBio();

// Spread syntax // ...
// let arr = [3, 5, 1];
// console.log(Math.max(arr)); // NaN
// console.log(Math.max(...arr)); // 5

// let arr1 = [1, -2, 3, 4];
// let arr2 = [8, 3, -8, 1];
// console.log(Math.max(1, ...arr1, 2, ...arr2, 25)); // 25

// let arr = [3,5,1];
// let arr2 = [8,9,15];
// let a = [0, ...arr, 2, ...arr2];
// console.log(a); // [0,3,5,1,2,8,9,15]

// let str = 'HELLO';
// console.log([...str]); // ['H', 'E', 'L', 'L', 'O']

// let str = 'HELLO';
// // Array.from()-y tvyal string-y veracum e array-i
// console.log(Array.from(str)); // ['H', 'E', 'L', 'L', 'O']

// const arr1 = [1,2,3,4];
// const arr2 = [5,6,7,8];
// console.log(arr1.concat(arr2)); // outputs [1,2,3,4,5,6,7,8];
// console.log([...arr1,...arr2]); // outputs [1,2,3,4,5,6,7,8];

// function.apply() //  apply-in function e, vory nerarum e ira mej function.apply(thisArg, [argsArray]), aysinqn inchvor argument u array
// Orinak
// function mySum(num1,num2,num3) {
//     console.log(num1+num2+num3);
// }
// let params = [32, 50, 21];
// mySum.apply(null, params); // outputs 103
// mySum(params); // outputs 32,50,21undefinedundefined
// mySum(...params); // outputs 103

// reduce-n ira mej neraruma function u kataruma et function-y array-i bolor elementneri vra dzaxic ach
// ORINAK
// let args = Array.from('12345'); // outputs ['1','2','3','4','5'];
// console.log(args.reduce(function(a,b) {
//     return a*b; 
// })); // outputs 120

// Orinak 1
// function mult() {
//     let args = Array.from(arguments);
// console.log(args.reduce(function(a,b) {
//     return a*b; 
// }));
// }
// mult(4,2); // outputs 8
// mult(2,3,4); // outputs 24

// Orinak 1-y spread syntax-ov // ...
// function mult(...args) {
// console.log(args.reduce(function(a,b) {
//     return a*b; 
// }));
// }
// mult(4,2); // outputs 8
// mult(2,3,4); // outputs 24

// let sequence = [1, 3, 2, 1];
// for(let i = 0; i<sequence.length; i++) {
//     // if(sequence.slice(i) != sequence.slice(i).sort()) {
//     //     console.log(false);
//     // }
// // console.log(sequence.slice(i).sort())
// }
// console.log(sequence.sort().slice(0,-1));
// let arr1 = [];
// for(let i = 0; i<sequence.length; i++) {
//     arr1.push(sequence.slice(i).sort());  
// }
// console.log(arr1);

// let sequence = [1,3,2,1];
// let a  = sequence.splice(1,1);
// console.log(sequence);

// function solution(n) {
//     let sum = 0;
//     let sum1 = 0;
//     let arr = String(n).split('')
//     let arrSize = arr.length/2;
//     let arrKes = [];
//     for (let i = 0; i <arr.length; i += arrSize) {
//         arrKes.push(arr.slice(i, i + arrSize));
//     }
//     arrKes[0].forEach(elem => sum += Number(elem));
//     arrKes[1].forEach(e => sum1 += Number(e));
//     if(sum === sum1) {
//         return true;
//     } else {
//         return false;
//     }
// }
// console.log(solution(1231));

// let a = {
//     'name': 'John',
//     age: 39,
//     phone: 7634872,
// };
// document.write(a); // [object Object]
// let str = JSON.stringify(a); // JSON-y inqy vorpes tvyal brauseri du sarqumes iran u veracumes toxi stringify-ov
// document.write(str); // {'name':'John','age':39,'phone':7634872}
// let obj = JSON.parse(str);
// document.write(obj); // [object Object] - vorovhetev eli parse-ov menq toxy het sarqecinq object

// let str = JSON.stringify(a);
// localStorage.setItem('anun', str); // localStorage-n JSON tvyaly(anpayman JSON-ov) vercnuma u setItem-ov sahmanuma eti localStorage-um, isk getItem-ov karanq stananq et, u kara nayev et stana urish cragravorox u vercni qci ira kodi meji u vren ashxati, nuynisk urish lezvov kodi mej popoxi u ogtagorci kanchelov en 'anun'-y vory menq kgrenq mejy
// localStorage.getItem('anun'); // localStorage-n ete es jnjem kodis mejic meka inqy pahpanvelua im brauserum

// JSON u heto localStorage chenq kara anenq object-i meji functiony, vorovhetev menq chenq kara gorcoxutyuny sarqenq string u heto tvyal, baci function-ic khavaqi mnacac sax tvyalneri u ksahmani localStorage-um
// Example 1
// let b = {
//     name: 'Alen',
//     phone: 87436,
//     friends: ['Mike','hg','jhy'],
//     sayHi: function() {alert('Hello');},
// };
// let b1 = JSON.stringify(b);
// localStorage.setItem('anun1',b1);
// localStorage.getItem(b1); // cuyc kta localStorage-um aranc function-i mnacay

// Example 2
// let c = {
//     f: function() {},
//     c: function() {},
// };
// let c1 = JSON.stringify(c);
// localStorage.setItem('anun3',c1);
// localStorage.getItem(c1); // output - {}

// Spread
// Example 1
// let a1 = 5;
// let b2 = {
//     lastName: 'Aleksanyan',
//     ...a1,
//     name: 'Jack',
// };
// console.log(b2); // output {lastName: 'Aleksanyan', name: 'Jack'} // 5-y chi beri vorovhetev a1-y sovorakan popoxakana, petqa lini array kam object vor karananq spread anenq

// Example 2
// let a1 = {
//     name: 'Ani',
//     phone: 876,
// };
// let b2 = {
//     lastName: 'Aleksanyan',
//     ...a1,
//     name: 'Jack',
// };
// console.log(b2); // output { lastName: 'Aleksanyan', name: 'Jack', phone: 876 } // chi poxi name-y Ani, vorovhetev object-i mej kody kardacvuma nerqevic verev u vory arajiny exav etel ktpi

// Example 3
// let a1 = {
//     name: 'Ani',
//     phone: 876,
// };
// let b2 = {
//     lastName: 'Aleksanyan',
//     name: 'Jack',
//     ...a1,
// };
// console.log(b2); // output { lastName: 'Aleksanyan', name: 'Ani', phone: 876 } // kpoxi name-y Ani, vorovhetev nerqevic verev arden arajin-y Ani-na

// function solution(inputString) {
// while(true){
//     if(inputString.includes(')')){
//     }
//     else if (inputString.indexOf(')') === -1){
//         break;
//     } 
//     let verjinbacvoxpakagic = inputString.substring(0,inputString.indexOf(')') + 1).split('').lastIndexOf('(');
//     let arajinpakvoxpakagic = inputString.indexOf(')');
//     let start = inputString.substring(0, verjinbacvoxpakagic);
//     let middle = inputString.substring(verjinbacvoxpakagic + 1, arajinpakvoxpakagic).split('').reverse().join('');
//     let end = inputString.substring(arajinpakvoxpakagic + 1, inputString.length);

//     inputString = start + middle + end;
//    }
//    return inputString;
// }
// console.log(solution('foo(bar(bar))baz'))

// function arraySum(array){
// var sum = 0;
// for(var i = 0; i < array.length; i++){
//     sum += array[i];
//     }
//     return sum;
// }
// function solution(a) {
//     let kentindexovner = [];
//     let zuygindexovner = [];
//     for(let i = 0; i<a.length; i++) {
//         if(i % 2 === 0) {
//             zuygindexovner.push(a[i]);
//         }
//         else {
//             kentindexovner.push(a[i]);
//         }
//     }
//     return [arraySum(zuygindexovner),arraySum(kentindexovner)];
// }
// console.log(solution([1]));

// function chakert(string) {
//     return '*' + string + '*';
// }

// function chakert1(string) {
//     let chakert = '';
//     for(let i = 0; i<string.length; i++) {
//         chakert += '*';
//         // console.log(chakert);
//     }
//     return chakert;
// }

// function solution(picture) {
//     let arr = [];
//     for(let i = 0; i<picture.length; i++) {
//         arr.push(chakert(picture[i]))
//     }
//     return [chakert1(picture[0]),...arr,chakert1(picture[0])];
// }

// function similiars(arr1, arr2){
//     return arr1.every(function(e){
//         return arr2.includes(e);
//     })
// }
// console.log(contains([1,2,3],[1,3,3]));

// function lastidx(a,b) {
//     let arr = [];
//     let sum = 0;
//     for(let i = 0; i<a.length; i++) {
//         arr.push(a.lastIndexOf(a[i]) === b.lastIndexOf(a[i]))
//     }
//     for(let x = 0; x<arr.length; x++){
//     if(arr[x] === false) {
//         sum++;
//     }
// }
//     return sum;
// }
// console.log(lastidx([832, 998, 148, 570, 533, 561, 894, 147, 455, 279],[832, 570, 148, 998, 533, 561, 455, 147, 894, 279]));

// function solution(a,b) {
// let sum = 0;
// let sum1 = 0;
// a.every(function(elem){
//     sum += elem;
//     return sum;
// })
// b.every(function(element){
//     sum1 += element;
//     return sum1;
// })
// if(a.every(function(e){
//     return b.includes(e);
// })===true && sum === sum1 && lastidx(a,b) > 1) {
//     return true;
// }
// else {
//     return false;
// }
// }
// console.log(solution([832, 998, 148, 570, 533, 561, 894, 147, 455, 279],[832, 570, 148, 998, 533, 561, 455, 147, 894, 279]))

// function Find_Not_Repeated_Character (string) {
//     let array = string.split('');
//     array.sort();
//     for(let i = 0; i<array.length; i++) {
//         if(array[i]===array[i+1]) {
//             delete(array[i]);
//             delete(array[i+1]);
//         }
//     }
//     return array.join('').length;
// }
// function solution(inputString) {
// if(Find_Not_Repeated_Character(inputString) % 2 === 0 && Find_Not_Repeated_Character(inputString) === 0 || Find_Not_Repeated_Character(inputString) === 1) {
//     return true;
// } else {
//     return false;
// }
// }
// console.log(solution('zyyzzzzz'));

// function solution(inputArray) {
//     let arr1 = [];
//     let arr2 = [];
//     for(let i = 0; i<inputArray.length - 1; i++) {
//         arr1.push(inputArray[i] - inputArray[i+1]);
//     }
//     for(let x = 0; x<arr1.length; x++) {
//         arr2.push(arr1[x]*arr1[x])
//     }
//     return Math.sqrt(Math.max(...arr2));
// }
// console.log(solution([2,4,1,0]));

// Xndir 1
// let button = document.querySelector("#button");
// button.addEventListener("click", function() {
//     alert('Hello World');
// })

// Xndir2
// let button = document.querySelector("#button");
// let button1 = document.querySelector("#button1");
// let button2 = document.querySelector("#button2");
// let num1 = Number(document.getElementById("num1").innerHTML);
// let num2 = Number(document.getElementById("num2").innerHTML);
// button1.addEventListener("click", function() {
//     console.log(num1);
// });
// button2.addEventListener("click", function() {
//     console.log(num2);
// });
// button.addEventListener("click", function() {
//     console.log(num1+num2);
// });

// function solution(inputArray) {
//     let max = Math.max(...inputArray);
//     for(let i = 1; i < max; i++) {
//         let min = inputArray.some(x => x % i == 0);
//         if(!min) return i;
//     }
//     return max + 1;
// }

// function solution(image) {
// let qarakusi = 3;
// let array = [];
// for(let i = 0; i < image.length; i++) {
//     let arr = [];
//     for(let j = 0; j < image[0].length; j++) {
//         let sum = 0;
//         if(image[i][j] !== undefined && image[i][j+2] !== undefined && image[i+2]) {
//             for(let x = 0; x < qarakusi; x++) {
//                 for(let y = 0; y < qarakusi; y++) {
//                     sum += image[i+x][j+y];
//                 }
//             }
//             arr.push(Math.floor(sum/9));
//         }
//     }
//     if(arr.length > 0) array.push(arr);
// }
// return array;
// }
// console.log(solution([[7,4,0,1],
//     [5,6,2,2],
//     [6,10,7,8],
//     [1,4,2,0]]))

